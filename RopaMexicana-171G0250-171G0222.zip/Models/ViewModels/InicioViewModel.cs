﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RopaMexicana_171G0250_171G0222.Models.ViewModels
{
    public class InicioViewModel
    {
        public IEnumerable<ProductoViewModel> Productos { get; set; }
    }
}
