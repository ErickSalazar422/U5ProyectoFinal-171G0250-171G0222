﻿using System;
using System.Collections.Generic;

namespace RopaMexicana_171G0250_171G0222.Models
{
    public partial class Administrador
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Contraseña { get; set; }
        public string Usuario { get; set; }
    }
}
